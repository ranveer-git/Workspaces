package cntrl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import bean.RestResponse;

@Controller
public class BaseController 
{

	@RequestMapping("/")
	public String serveBasicRequest(ModelMap mm)
	{
		mm.addAttribute("name", "Maha");
		return "index";
	}
	
	@RequestMapping("/getCountries")
	public String fetchCountries(ModelMap mm)
	{
		RestTemplate rt = new RestTemplate();
		
		List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();
		messageConverters.add(new FormHttpMessageConverter());
		messageConverters.add(new StringHttpMessageConverter());
		messageConverters.add(new MappingJackson2HttpMessageConverter());
		rt.setMessageConverters(messageConverters);
		
		String url = "http://services.groupkt.com/country/get/all";
		RestResponse res = rt.getForObject(url, RestResponse.class);
		
		System.out.println(res);
		
		return "listOfCountries";
		
	}
}
